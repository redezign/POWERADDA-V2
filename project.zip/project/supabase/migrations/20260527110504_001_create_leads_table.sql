/*
  # Create leads table

  Stores customer inquiries and service requests from the PowerAdda website.

  1. New Tables
    - `leads`
      - `id` (uuid, primary key)
      - `full_name` (text, required) - Customer's full name
      - `mobile_number` (text, required) - Customer's 10-digit mobile number
      - `service_type` (text, required) - Type of service requested
      - `vehicle_type` (text, optional) - Type of vehicle if applicable
      - `location` (text, optional) - Customer's location in Mumbai
      - `message` (text, optional) - Additional message or requirements
      - `status` (text, default: 'new') - Lead status (new, contacted, converted, closed)
      - `created_at` (timestamp, auto) - When the lead was submitted
      - `updated_at` (timestamp, auto) - When the lead was last updated

  2. Security
    - Enable RLS on `leads` table
    - Allow anonymous INSERT for form submissions (website visitors)
    - Restrict SELECT/UPDATE/DELETE to authenticated users only
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL CHECK (char_length(full_name) >= 2),
  mobile_number text NOT NULL CHECK (mobile_number ~ '^[6-9][0-9]{9}$'),
  service_type text NOT NULL,
  vehicle_type text,
  location text,
  message text,
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'converted', 'closed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

-- Allow anonymous users (website visitors) to insert leads
CREATE POLICY "Anyone can submit a lead"
  ON leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Only authenticated users can view leads
CREATE POLICY "Authenticated users can view leads"
  ON leads FOR SELECT
  TO authenticated
  USING (true);

-- Only authenticated users can update leads
CREATE POLICY "Authenticated users can update leads"
  ON leads FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Only authenticated users can delete leads
CREATE POLICY "Authenticated users can delete leads"
  ON leads FOR DELETE
  TO authenticated
  USING (true);

-- Create index on mobile_number for faster lookups
CREATE INDEX IF NOT EXISTS idx_leads_mobile_number ON leads(mobile_number);

-- Create index on status for filtering
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);

-- Create index on created_at for sorting
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at DESC);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_leads_updated_at
  BEFORE UPDATE ON leads
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
