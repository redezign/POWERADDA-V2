/*
  # Create vendor_partners table

  Stores partnership applications from businesses wanting to partner with PowerAdda.

  1. New Tables
    - `vendor_partners`
      - `id` (uuid, primary key)
      - `business_name` (text, required) - Business or company name
      - `contact_person` (text, required) - Contact person's full name
      - `mobile_number` (text, required) - Contact mobile number
      - `category` (text, required) - Business category type
      - `city` (text, required) - City location
      - `message` (text, optional) - Additional message about partnership
      - `status` (text, default: 'new') - Application status (new, reviewing, approved, rejected)
      - `created_at` (timestamp, auto) - When the application was submitted
      - `updated_at` (timestamp, auto) - When the application was last updated

  2. Security
    - Enable RLS on `vendor_partners` table
    - Allow anonymous INSERT for form submissions
    - Restrict SELECT/UPDATE/DELETE to authenticated users only
*/

CREATE TABLE IF NOT EXISTS vendor_partners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_name text NOT NULL CHECK (char_length(business_name) >= 2),
  contact_person text NOT NULL CHECK (char_length(contact_person) >= 2),
  mobile_number text NOT NULL CHECK (mobile_number ~ '^[6-9][0-9]{9}$'),
  category text NOT NULL,
  city text NOT NULL CHECK (char_length(city) >= 2),
  message text,
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'reviewing', 'approved', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE vendor_partners ENABLE ROW LEVEL SECURITY;

-- Allow anonymous users to submit applications
CREATE POLICY "Anyone can submit a partnership application"
  ON vendor_partners FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Only authenticated users can view applications
CREATE POLICY "Authenticated users can view applications"
  ON vendor_partners FOR SELECT
  TO authenticated
  USING (true);

-- Only authenticated users can update applications
CREATE POLICY "Authenticated users can update applications"
  ON vendor_partners FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Only authenticated users can delete applications
CREATE POLICY "Authenticated users can delete applications"
  ON vendor_partners FOR DELETE
  TO authenticated
  USING (true);

-- Create index on mobile_number for faster lookups
CREATE INDEX IF NOT EXISTS idx_vendor_partners_mobile ON vendor_partners(mobile_number);

-- Create index on status for filtering
CREATE INDEX IF NOT EXISTS idx_vendor_partners_status ON vendor_partners(status);

-- Create index on created_at for sorting
CREATE INDEX IF NOT EXISTS idx_vendor_partners_created_at ON vendor_partners(created_at DESC);

-- Create index on category for filtering
CREATE INDEX IF NOT EXISTS idx_vendor_partners_category ON vendor_partners(category);

-- Create trigger to update updated_at timestamp (reuse existing function)
CREATE TRIGGER update_vendor_partners_updated_at
  BEFORE UPDATE ON vendor_partners
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
